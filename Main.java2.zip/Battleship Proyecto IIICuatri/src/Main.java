import java.util.Scanner;
import java.util.Stack;
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        Scanner entrada2 = new Scanner(System.in);
        int star;
        System.out.println("""
                \033[34m
                ************************************
                *   🌊💥  Battleship Game   🚢💣  *
                *  Introducción a la programación  *            
                *  Profesor: Jose A. Rivera Tencio *
                *             Grupo 05             *  
                *           Estudiantes:           * 
                *       Amber Bustos Araya         * 
                *       Rachel Cortés Torres       *
                *       Joseph Garay Morales       *
                *       Arleth Serrano Rodriguez   *                             
                ************************************
                """);
        System.out.print("\033[34mPresione 1 para empezar el juego");
        star = entrada2.nextInt();
        switch (star) {
            case 1 -> Start();
            default -> System.out.println("Hasta la próxima!");
        }
    }

    tableros tablero = new tableros();
    char[][] TuTablero = tablero.crearTablero(tablero.gettamanoTablero(), tablero.getagua());
    char[][] TableroEnemigo = tablero.crearTablero(tablero.gettamanoTablero(), tablero.getagua());
    char agua = tablero.getagua();


    private static void ImprimirTablero(char[][] tablero, char agua) {
        byte tamanoTablero = (byte) tablero.length;
        System.out.print("  ");
        for (byte i = 0; i < tamanoTablero; i++) {
            System.out.print(i + 1 + " ");
        }
        System.out.println();
        for (byte fila = 0; fila < tamanoTablero; fila++) {
            System.out.print(fila + 1 + " ");
            for (byte columna = 0; columna < tamanoTablero; columna++) {
                char Posicion = tablero[fila][columna];
                //escondemos los barcos con agua
                //de momento rellenamos solo con agua ya que no hay barcos
                if (Posicion == agua) {
                    System.out.print(agua + " ");
                } else {
                    System.out.print(Posicion + "  ");
                }
            }
            System.out.println();
        }
    }


    private static void Start() {

        int AlmirantePC = 1;
        int Capitan1PC = 3;
        int Capitan2PC = 3;
        int Capitan3PC = 3;
        int Teniente1PC = 1;
        int Teniente2PC = 1;
        int Teniente3PC = 1;

        // Naves propias
        char Almirante = 4;
        int Capitan1 = 3;
        int Capitan2 = 3;
        int Teniente1 = 1;
        int Teniente2 = 1;
        int Teniente3 = 1;

        String[] nombres = new String[2];
        System.out.println("\nIngresar los nombres de los jugadores ");
        // Se piden los nombres a los jugadores
        Scanner entrada3 = new Scanner(System.in);
        Scanner entrada4 = new Scanner(System.in);
        System.out.print("\033[34mNombre del jugador 1 \uD83D\uDC64= ");
        String jugador1 = entrada3.nextLine();
        System.out.print("Nombre del jugador 2 \uD83D\uDC64= ");
        String jugador2 = entrada4.nextLine();
        nombres[0] = jugador1;
        nombres[1] = jugador2;

        tableros tablero = new tableros();
        int Aleatorios[] = new int[6];
        int Aleatorios2[] = new int[6];



        char[][] TuTablero = tablero.crearTablero(tablero.gettamanoTablero(), tablero.getagua());
        char[][] TableroEnemigo = tablero.crearTablero(tablero.gettamanoTablero(), tablero.getagua());
        char[][] TableroenemigoAtacado = tablero.crearTablero(tablero.gettamanoTablero(), tablero.getagua());

        char agua = tablero.getagua();

        Stack<Integer> Numeros = new Stack<Integer>();
        Random Rnd = new Random();
        int Aleatorio;
        for (int x = 0; x < 6; x++) {
            Aleatorio = (int) (Rnd.nextDouble() * 6);
            while (Numeros.contains(Aleatorio)) {
                Aleatorio = (int) (Rnd.nextDouble() * 6);
                //Posiciones de las naves enemigas
            }
            Numeros.push(Aleatorio);
            Aleatorios[x] = Aleatorio;
        }

        Stack<Integer> Numeros2 = new Stack<Integer>();
        Random Rnd2 = new Random();
        int Aleatorio2;
        for (int w = 0; w < 6; w++) {
            Aleatorio2 = (int) (Rnd2.nextDouble() * 6);
            while (Numeros2.contains(Aleatorio2)) {
                Aleatorio2 = (int) (Rnd2.nextDouble() * 6);
                //Posiciones de las naves enemigas
            }
            Numeros2.push(Aleatorio2);
            Aleatorios[w] = Aleatorio2;
        }
        TableroEnemigo[Aleatorios[0]][Aleatorios2[0]] = 4;
        TableroEnemigo[Aleatorios2[1]][Aleatorios[1]] = 3;
        TableroEnemigo[Aleatorios[2]][Aleatorios2[2]] = 3;
        TableroEnemigo[Aleatorios2[3]][Aleatorios[3]] = 1;
        TableroEnemigo[Aleatorios2[4]][Aleatorios[4]] = 1;
        TableroEnemigo[Aleatorios2[5]][Aleatorios[5]] = 1;


        System.out.println("Ingrese donde quiere colocar sus naves "+nombres[0]);
        Scanner s = new Scanner(System.in);
        int col;
        int fila;
        System.out.println("Ingrese donde quiere colocar la nave del almirante, Capitan");
        System.out.println("Fila:");
        fila = s.nextInt();
        System.out.println("Columna");
        col = s.nextInt();
        // Busca en el tablero y coloca la nave
        TuTablero[fila][col] = Almirante;
        System.out.println("----" + nombres[0] + "----");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(TuTablero[i][j]);
                System.out.print(" ");
            }
            System.out.println(" ");
        }

        Scanner c = new Scanner(System.in);
        Scanner c2 = new Scanner(System.in);
        int colc;
        int filac;
        int colc2;
        int filac2;
        System.out.println("                                             ");
        System.out.println("Ingrese donde quiere colocar sus naves Capitan");
        System.out.println("Fila:");
        filac = c.nextInt();
        System.out.println("Columna");
        colc = c.nextInt();
        System.out.println("Fila:");
        filac2 = c2.nextInt();
        System.out.println("Columna");
        colc2 = c2.nextInt();
        // Busca en el tablero y coloca la nave

        TuTablero[filac][colc] = '3';
        TuTablero[filac2][colc2] = '3';

        System.out.println("----" + nombres[0] + "----");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(TuTablero[i][j]);
                System.out.print(" ");
            }
            System.out.println(" ");
        }

        Scanner t = new Scanner(System.in);
        Scanner t2 = new Scanner(System.in);
        Scanner t3 = new Scanner(System.in);
        int colt;
        int filat;
        int colt2;
        int filat2;
        int colt3;
        int filat3;

        System.out.println("                                             ");
        System.out.println("Ingrese donde quiere colocar las naves de tenientes Capitan");
        System.out.println("Fila:");
        filat = t.nextInt();
        System.out.println("Columna");
        colt = t.nextInt();

        System.out.println("Fila:");
        filat2 = t2.nextInt();
        System.out.println("Columna");
        colt2 = t2.nextInt();

        System.out.println("Fila:");
        filat3 = t3.nextInt();
        System.out.println("Columna");
        colt3 = t3.nextInt();

        // Busca en el tablero y coloca la nave
        TuTablero[filat][colt] = '1';
        TuTablero[filat2][colt2] = '1';
        TuTablero[filat3][colt3] = '1';

        System.out.println("----" + nombres[0] + "----");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(TuTablero[i][j]);
                System.out.print(" ");
            }
            System.out.println(" ");
        }


        // Naves PC

        Scanner entrada = new Scanner(System.in);
        int menu;
        boolean salir = true;
        while (salir) {
            System.out.println("1 - Atacar\"");
            System.out.println("2 -Ver tablero de ataque");
            System.out.println("3 - Ver tablero propio  ");
            System.out.println("4 -Hacer trampa");
            System.out.println("6 -Exit");
            menu = entrada.nextInt();
            switch (menu) {
                case 1:
                    System.out.println("\n5 Atacar");
                    int filaataque;
                    int columataque;
                    int Ataques[] = new int[2];
                    Scanner fa = new Scanner(System.in);
                    Scanner ca = new Scanner(System.in);
                    System.out.println("\nNaves posicionadas...");
                    System.out.println("Fila:");
                    filaataque = fa.nextInt();
                    System.out.println("Columna");
                    columataque = ca.nextInt();

                    Ataques[0] = filaataque;
                    Ataques[1] = columataque;

                    if (TuTablero[Ataques[0]][Ataques[1]] == TuTablero[fila][col]) {
                        System.out.println("Le diste a una nave de almirante!");
                        Almirante = (char) (Almirante-1);
                        TuTablero[fila][col] = Almirante;
                    } else if (TuTablero[Ataques[0]][Ataques[1]] != TuTablero[fila][col]){
                        System.out.println("El misil cayó en el agua!");
                        TuTablero[Ataques[0]][Ataques[1]] = 'X';

                    }

                    System.out.println(" ");
                    break;

                case 2:
                    System.out.println("\n3 Ver tablero de ataque");
                    System.out.println("----" + nombres[1] + "----");
                    ImprimirTablero(TableroenemigoAtacado, agua);

                    break;
                case 3:
                    System.out.println("\n2 Ver tablero propio");
                    System.out.println("----" + nombres[0] + "----");
                    ImprimirTablero(TuTablero, agua);
                    break;
                case 5:
                    System.out.println("\n6 Hacer trampa");
                    System.out.println("----" + nombres[1] + "----");
                    for (int i = 0; i < 6; i++) {
                        for (int j = 0; j < 6; j++) {
                            System.out.print(TableroEnemigo[i][j]);
                            System.out.print(" ");
                        }
                        System.out.println(" ");
                    }
                    break;

                case 6:
                    System.out.println("\nSalida del juego!");
                    salir = false;
                    break;
                default:
                    System.out.println("\n *Error: Ingrese una opción válida");
                    break;
            }
        }
    }
}


